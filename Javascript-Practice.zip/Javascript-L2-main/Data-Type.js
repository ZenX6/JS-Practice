// your code here
function hasDoubleLetter(word){
    if (typeof word !== 'string'){
        return null;
    }
    
    for (let i = 0; i < word.length; i++){
        if (word[i] === word[i + 1]){
            return true;
        }
    }
    return false;
}
console.log(hasDoubleLetter('deer')); // true
console.log(hasDoubleLetter('boot camp')); // true
console.log(hasDoubleLetter('toggle')); // true
console.log(hasDoubleLetter('taco')); // false
console.log(hasDoubleLetter('jumper')); // false
console.log(hasDoubleLetter(18)); // null
console.log(hasDoubleLetter(['array'])); // null


function firstVowel(word){
   
    if (typeof word !== 'string'){
        return null;
    }
   
    let vowels = 'aeiou'
    
    for (let char of word){
        if (vowels.includes(char)){
            return char
        }
    }
    return null
}
console.log(firstVowel('battery')); // 'a'
console.log(firstVowel('tunnel')); // 'u'
console.log(firstVowel('dog')); // 'o'
console.log(firstVowel('conventional')); // 'o'
console.log(firstVowel('rhythm')); // null


// your code here
function lastVowel(word){
    let vowels = 'aeiouAEIOU'

    for (i = word.length - 1; i >= 0; i--){
        if (vowels.includes(word[i])){
            return word[i];
        }
    } 
    return null;
}




console.log(lastVowel('battery')); // 'e'
console.log(lastVowel('TUNNEL')); // 'E'
console.log(lastVowel('dog')); // 'o'
console.log(lastVowel('conventional')); // 'a'
console.log(lastVowel('rhythm')); // null
