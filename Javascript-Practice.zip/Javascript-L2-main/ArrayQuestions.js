function wordWithinArray(arr, word){
    for (let i = 0; i < arr.length; i++){
        if (arr[i] === word){
            return true
        }
    }
    return false
}

console.log(
    wordWithinArray(["apple", "banana", "caramel", "chocolate"], "apple")
  ); //=> true
  
  console.log(wordWithinArray(
    ["dog", "cat", "camel", "bird"], "camel")
  ); //=> true
  
  console.log(
    wordWithinArray(["apple", "banana", "caramel", "chocolate"], "pineapple")
  ); //=> false
  
  console.log(wordWithinArray(
    ["dog", "cat", "camel", "bird"], "panther")
  ); //=> false

  function wordWithinArray(array,word){
    return array.indexOf(word) !== -1
  }


function firstAndLast(arr){
    if (arr.length === 0){
        return null

    }
    if (arr.length % 2 === 0){
        return arr[0] + arr[arr.length - 1]
    } else{
        return arr[0] - arr[arr.length - 1]
    }
}

console.log(firstAndLast([1, 2, 3, 4]));    // 5
console.log(firstAndLast([1, 2, 3, 4, 5])); // -4
console.log(firstAndLast([12, 5]));         // 17
console.log(firstAndLast([12]));            // 0
console.log(firstAndLast([7, 11, 3]));      // 4

// Your code here
function threeIncreasing(arr){
    for (let i = 0; i < arr.length - 2; i++){
        if (arr[i + 1] === arr[i] + 1 && arr[i + 2] === arr[i] + 2){
            return true
        }
    }
    return false
}

console.log(threeIncreasing([3, 2, 11, 12, 13, 2, 4]));     // true
console.log(threeIncreasing([2, 7, 8, 9]));                 // true
console.log(threeIncreasing([7, 2, 4, 5, 2, 1, 6]));        // false
console.log(threeIncreasing([1, 2, 4, 5, 2, 7, 8]));        // false

// your code here
function myIncludes(arr, target){
    for (let i = 0; i < arr.length; i++){
        if (arr[i] === target){
            return true
        }
    }
    return false
}






console.log(myIncludes(['a', 'b', 'c', 'e'], 'c')); // true
console.log(myIncludes(['a', 'b', 'c', 'e'], 'a')); // true
console.log(myIncludes(['a', 'b', 'c', 'e'], 'z')); // false
console.log(myIncludes([43, -7, 11, 13], 11)); // true
console.log(myIncludes([43, -7, 11, 13], 1)); // false


// your code here
function myIndexOf(arr,word){
    for (let i = 0; i < arr.length; i++){
        if (arr[i] === word){
            return i
        }
    }
    return -1
}

console.log(myIndexOf(['a', 'b', 'c', 'e'], 'c')); // 2
console.log(myIndexOf(['a', 'b', 'c', 'e'], 'e')); // 3
console.log(myIndexOf(['a', 'b', 'c', 'e'], 'z')); // -1
console.log(myIndexOf([43, -7, 11, 13, 43], 43)); // 0
console.log(myIndexOf([43, -7, 11, 13], 1)); // -1


function sumArray(arr) {
   let sum = 0 
   for (let i = 0; i < arr.length; i++){
        sum += arr[i]
        
    }
    return sum
}

console.log(sumArray([5, 6, 4])); // => 15
console.log(sumArray([7, 3, 9, 11])); // => 30


// your code here
function productWithReduce(arr){
    let sum = 1
    for (let i = 0; i < arr.length; i++){
        sum *= arr[i]
    }
    return sum
}



console.log(productWithReduce([10, 3, 5, 2])); // 300
console.log(productWithReduce([4, 3])); // 12

function doubler(numbers) {
    let sum =[]
   for (let i = 0; i < numbers.length; i++){
    sum.push(numbers[i] * 2)
   }
    return sum
}

console.log(doubler([1, 2, 3, 4])); // => [2, 4, 6, 8]
console.log(doubler([7, 1, 8])); // => [14, 2, 16]

function isPrime(num){
    if (num < 2){
        return false
    }

    for (i = 2; i <= Math.sqrt(num); i++){
        if (num % i === 0){
            return false
        }
    }
    return true
}

console.log(isPrime(2)); // => true
console.log(isPrime(10)); // => false
console.log(isPrime(11)); // => true
console.log(isPrime(9)); // => false
console.log(isPrime(2017)); // => true

// your code here
function choosePrimes(arr){
    let primes = []
    for (let i = 0; i < arr.length; i++){
        if(isPrime(arr[i])){
            primes.push(arr[i])
        }
    } 
    return primes
    
}
console.log(choosePrimes([36, 48, 9, 13, 19])); // [ 13, 19 ]
console.log(choosePrimes([5, 6, 4, 11, 2017])); // [ 5, 11, 2017 ]

// Your code here
function nextPrime(num){
    num++
    while (true){
        if(isPrime(num)){
            return num
        }
        num++
    }
    
}


console.log(nextPrime(2)); // 3
console.log(nextPrime(3)); // 5
console.log(nextPrime(7)); // 11
console.log(nextPrime(8)); // 11
console.log(nextPrime(20)); // 23
console.log(nextPrime(97)); // 101



// Your code here
function primeFactors(num){
    let factors = [];

    for(let i = 2; i <= num; i++){
        if (num % i === 0 && isPrime(i)){
            factors.push(i)
        }
    }
    return factors
}


console.log(primeFactors(12));  // [2, 3]
console.log(primeFactors(7));   // [7]
console.log(primeFactors(16));  // [2]
console.log(primeFactors(30));  // [2, 3, 5]
console.log(primeFactors(35));  // [5, 7]
console.log(primeFactors(49));  // [7]
console.log(primeFactors(128)); // [2]


function mostVowels(sentence) {
    let words = sentence.split(' ')
    let maxVowels = 0;
    let wordWithMostVowels = ""

    for (let word of words){
        let currentVowelCount = countvowels(word)
        if (currentVowelCount > maxVowels){
            maxVowels = currentVowelCount;
            wordWithMostVowels = word;
        }
    }
    return wordWithMostVowels
}

function countvowels(word){
    let count = 0
    let vowels = 'aeiou'

    for(let char of word){
        if (vowels.includes(char)){
            count++
        }
    }
    return count;

}

console.log(mostVowels("what a wonderful life")); // "wonderful"


function allElseEqual(arr) {
    let sum = arr.reduce((acc,curr) => acc + curr, 0);

    for (let num of arr){
        if (num === sum / 2){
            return num
        }
    }
    return null
}

console.log(allElseEqual([2, 4, 3, 10, 1])); // 10
console.log(allElseEqual([6, 3, 5, -9, 1])); // 3
console.log(allElseEqual([1, 2, 3, 4]));     // null