function addToArray(location, element, arr) {
    if (location === 'FRONT'){
        arr.unshift(element);
    } else if (location === 'BACK'){
        arr.push(element)
    } else{
        console.log("ERROR")
    }



}
testArray = [1,2,3]

addToArray("FRONT", 0, testArray)
console.log(testArray) // [0,1,2,3]

addToArray("BACK", 4, testArray)
console.log(testArray) // [0,1,2,3,4]

addToArray("MIDDLE", 4, testArray) // "ERROR"
console.log(testArray) // [0,1,2,3,4]


function evenNumbers(num){
    let result = []

    for (let i = 2; i <= num; i += 2){
        if (i % 2 === 0){
            result.push(i)
        }
    }
    return result
}
console.log(evenNumbers(7)); // [ 2, 4, 6 ]
console.log(evenNumbers(12)); // [ 2, 4, 6, 8, 10 ]
console.log(evenNumbers(15)); // [ 2, 4, 6, 8, 10, 12, 14 ]


function logBetweenStepper(min, max, step){
    let result = []
    
    for (i = min; i <= max; i += step){
        result.push(i)
    }
    console.log(result)
}
logBetweenStepper(5, 9, 1); // prints out:
5
6
7
8
9


logBetweenStepper(-10, 15, 5)  // prints out:
-10
-5
0
5
10
15


function factorsOf(num){
let result = []

for (let i = 0; i <= num; i++){
    if (num % i === 0){
        result.push(i)
    }
}
return result
}

console.log(factorsOf(5)); // [ 1, 5 ]
console.log(factorsOf(8)); // [ 1, 2, 4, 8 ]
console.log(factorsOf(9)); // [ 1, 3, 9 ]
console.log(factorsOf(10)); // [ 1, 2, 5, 10 ]
console.log(factorsOf(24)); // [ 1, 2, 3, 4, 6, 8, 12, 24 ]
console.log(factorsOf(2017)); // [ 1, 2017 ]


function fizzBuzz(num){
let result = []

    for (i = 1; i < num; i++){
        if ((i % 3 === 0 || i % 5 === 0) && !(i % 3 === 0 && i % 5 === 0)){
            result.push(i) 
        }
    }
    return result
}
console.log(fizzBuzz(12)); // [ 3, 5, 6, 9, 10 ]
console.log(fizzBuzz(20)); // [ 3, 5, 6, 9, 10, 12, 18 ]


function pitPat(num){
    let result = []
    
    for (let i = 1; i < num; i++){
        if ((i % 4 === 0 || i % 6 === 0) && !(i % 4 === 0 && i % 6 === 0)){
            result.push(i)
        }
    }
    return result
}
console.log(pitPat(18)); // [ 4, 6, 8, 16, 18 ]
console.log(pitPat(30)); // [ 4, 6, 8, 16, 18, 20, 28, 30 ]


function doubleSequence(length, base){
    let result = []

    if (base === 0){
        return result
    }

    for (let i = 0; i < length; i++){
        result.push(length);
        length *= base
    }
    return result
}



console.log(doubleSequence(7, 3));  // [7, 14, 28]
console.log(doubleSequence(3, 5));  // [3, 6, 12, 24, 48]
console.log(doubleSequence(5, 3));  // [5, 10, 20]
console.log(doubleSequence(5, 4));  // [5, 10, 20, 40]
console.log(doubleSequence(5, 0));  // [ ]