function minValue(array){
    if (array.length === 0){
        return null
    }
    return Math.min(...array)
}
console.log(minValue([4, 6, 3, 5, 2, 4])); // 2
console.log(minValue([-2, -3, -7, 3 ])); // -7
console.log(minValue([])); // null


function avgVal(array){
    if (array.length === 0){
        return null;
    }

    let sum = 0

    for (let i = 0; i < array.length; i++){
        
        sum += array[i]
       
    } 
    return sum / array.length
}
console.log(avgVal([5, 10])); // 7.5
console.log(avgVal([3, 7, 2, 1, 2])); // 3
console.log(avgVal([])); // null


function maxValue(nums){
    if (nums.length === 0){
        return null;
    }
    return Math.max(...nums)
}
console.log(maxValue([4, 6, 3, 5, 42, 4])); // 42
console.log(maxValue([-2, -3, -7, 3 ])); // 3
console.log(maxValue([])); // null



// Your code here
function reverb(word){
    if (typeof word !== 'string'){
        return null    
    }

    let vowels = 'aeiouAEIOU'
    let lastVowelIdx = -1

    for (let i = word.length -1; i >= 0; i--){
        if (vowels.includes(word[i])){
            lastVowelIdx = i
            break;
        }
    }

    if (lastVowelIdx === -1){
        return word
    }
    return word + word.slice(lastVowelIdx)
}



console.log(reverb('running')); // runninging
console.log(reverb('FAMILY'));  // FAMILYILY
console.log(reverb('trash'));   // trashash
console.log(reverb('DISH'));    // DISHISH
console.log(reverb(197393));    // null

function prevPrime(num){
    if (num <= 2){
        return null
    }

    let prev = num - 1

    while (prev > 1){
        if (isPrime(prev)){
            return prev

    }
    prev--
    }
    return null
}



console.log(prevPrime(32)); // 31
console.log(prevPrime(33)); // 31
console.log(prevPrime(14)); // 13
console.log(prevPrime(7));  // 5
console.log(prevPrime(4));  // 3
console.log(prevPrime(2));  // null
console.log(prevPrime(1));  // null

function isPrime(num){
    if (num < 2){
        return false
    }

    for (i = 2; i <= Math.sqrt(num); i++){
        if (num % i === 0){
            return false
        }
    }
    return true
}