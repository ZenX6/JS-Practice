// Third Question
function rotate(arr, num){
    let actualShifts = (num + arr.length) % arr.length

    let removed = arr.splice(-actualShifts)

    arr.unshift(...removed)
}


let arr = ['a', 'b', 'c', 'd', 'e'];
rotate(arr, 2);
console.log(arr); // [ 'd', 'e', 'a', 'b', 'c' ]

let animals = ['wombat', 'koala', 'opossum', 'kangaroo'];
rotate(animals, -1);
console.log(animals); // [ 'koala', 'opossum', 'kangaroo', 'wombat' ]

function initials(str){
    let words = str.split(' ')

    let char = words.map(word => word[0].toUpperCase())

    return char.join('')
}
console.log(initials('anna paschall')); // 'AP'
console.log(initials('Mary La Grange')); // 'MLG'
console.log(initials('brian crawford scott')); // 'BCS'
console.log(initials('Benicio Monserrate Rafael del Toro Sánchez')); // 'BMRDTS'


function longestWord(arr){
    let words = arr.split(' ')

    let longest = ''

    for (let i = 0; i < words.length; i++){
        if (words[i].length > longest.length){
            longest = words[i]
        }
    }
    return longest;
}
console.log(longestWord('where did everyone go')); // 'everyone'
console.log(longestWord('prefer simplicity over complexity')); // 'simplicity'
console.log(longestWord('')); // ''

function reverseSentence(sentence){
    let words = sentence.split(' ')

    let reversedWords = words.reverse()

    let reversedSentence = reversedWords.join(' ')

    return reversedSentence
}
console.log(reverseSentence('I am pretty hungry')); // 'hungry pretty am I'
console.log(reverseSentence('follow the yellow brick road')); // 'road brick yellow the follow'

function removeVowels(word){
    const vowels = 'AEIOUaeiou'

    let result  = ''

    for (let i = 0; i < word.length; i++){
        let char = word[i]
        if (!vowels.includes(char)){
            result += char
        }
    }
    return result
}

function abbreviateWords(str){
    let words = str.split(' ')

    for (let i = 0; i < words.length; i++){
        let word = words[i]

        if (word.length > 4){
            words[i] = removeVowels(word)
        }
    }
    return words.join(' ')
}
console.log(abbreviateWords('what a wonderful place to live')); // what a wndrfl plc to live
console.log(abbreviateWords('she sends an excellent message '));// she snds an xcllnt mssg

function snakeToCamel(str){
    let words = str.split('_')

    let capitalization = words.map(word => {
        return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    })
    return capitalization.join('')
}
console.log(snakeToCamel('snakes_go_hiss')); // 'SnakesGoHiss'
console.log(snakeToCamel('say_hello_world')); // 'SayHelloWorld'
console.log(snakeToCamel('app_academy_is_cool')); // 'AppAcademyIsCool'
console.log(snakeToCamel('APp_ACADEMY_iS_cOol')); // 'AppAcademyIsCool'

function removeLastVowel(word){
    const vowels = 'AEIOUaeiou'

    for (i = word.length - 1; i>= 0; i--){
        if (vowels.includes(word[i])){
            return word.slice(0, i) + word.slice(i + 1)
        }
    }
    return word
}

function hipsterfy(sentence){
    let words = sentence.split(' ')

    let modifiedWords = words.map(word => removeLastVowel(word))
    
    return modifiedWords.join(' ')
}

console.log(hipsterfy('proper')); // 'propr'
console.log(hipsterfy('proper tonic panther')); // 'propr tonc panthr'
console.log(hipsterfy('boot camp')); // 'bot cmp'
console.log(hipsterfy('towel flicker banana')); // 'towl flickr banan'
console.log(hipsterfy('runner anaconda')); // 'runnr anacond'
console.log(hipsterfy('turtle cheeseburger fries')); // 'turtl cheeseburgr fris'


function isVowel(char){
    const vowels = 'AEIOUaeiou'
    
    for (let i = 0; i < vowels.length; i++) {
        if (char === vowels[i]) {
            return true;
        }
    }

    return false;
}

function transformWord(word){
    if (word.length < 3){
        return word
    }
    
    for (let i = word.length - 1; i >= 0; i++){
        if (isVowel(word[i])){
            return word + word.slice(i)
        }
    }
    return word
}

function repeatingTranslate(sentence){
    let wordsArray = sentence.split(' ')
    
    for (let i = 0; i < wordsArray.length; i++){
        wordsArray[i] = transformWord(wordsArray[i])
    }
    
    return wordsArray.join(' ')
}


console.log(repeatingTranslate("we like to go running fast"));  // "we likelike to go runninging fastast"
console.log(repeatingTranslate("he cannot find the trash"));    // "he cannotot findind thethe trashash"
console.log(repeatingTranslate("pasta is my favorite dish"));   // "pastapasta is my favoritefavorite dishish"
console.log(repeatingTranslate("her family flew to France"));   // "herer familyily flewew to FranceFrance"