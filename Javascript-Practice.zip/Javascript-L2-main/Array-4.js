function commonFactors(num1, num2){
    let factors = []

    let min = Math.min(num1, num2)

    for (let i = 0; i <= min; i++){
        if (num1 % i === 0 && num2 % i === 0){
            factors.push(i)
        }
    }
    return factors
}
console.log(commonFactors(50, 30));            // [1, 2, 5, 10]
console.log(commonFactors(8, 4));              // [1, 2, 4]
console.log(commonFactors(4, 8));              // [1, 2, 4]
console.log(commonFactors(12, 24));            // [1, 2, 3, 4, 6, 12]
console.log(commonFactors(22, 44));            // [1, 2, 11, 22]
console.log(commonFactors(7, 9));              // [1]


function adjacentSums(arr){
    let sum = []

    for (let i = 0; i < arr.length - 1; i++){
        sum.push(arr[i] + arr[i + 1])
    }
    return sum
}
console.log(adjacentSums([3, 8, 7, 1]));        // [ 11, 15, 8 ]
console.log(adjacentSums([10, 5, 4, 3, 9]));    // [ 15, 9, 7, 12 ]
console.log(adjacentSums([2, -3, 3]));          // [-1, 0]


function fibonacciSequence(num){
    if (num === 0){
        return []
    }

    if (num === 1){
        return [1]
    }

    const result = [1, 1]

    for (let i = 2; i < num; i++){
        result.push(result[i - 1] + result[i - 2])

    }
    return result
}

console.log(fibonacciSequence(4));  // [ 1, 1, 2, 3 ]
console.log(fibonacciSequence(5));  // [ 1, 1, 2, 3, 5 ]
console.log(fibonacciSequence(8));  // [ 1, 1, 2, 3, 5, 8, 13, 21 ]
console.log(fibonacciSequence(0));  // [ ]
console.log(fibonacciSequence(1));  // [ 1 ]
console.log(fibonacciSequence(2));  // [ 1, 1 ]

function isPrime(num){
    if (num < 2) return false

    for (let i = 2; i <= Math.sqrt(num); i++){
        if (num % i === 0) return false
    }
    return true
}
function pickPrimes(array) {
   return array.filter(isPrime)
}

console.log(pickPrimes([2, 3, 4, 5, 6]));  // [2, 3, 5]
console.log(pickPrimes([101, 20, 103, 2017]));  // [101, 103, 2017]


function greatestFactor(num) {
   for (let i = num; i >= 1; i--){
    if (num % i === 0) return i;
   }
   return num;
}
function greatestFactorArray(arr){
    return arr.map(num => {
        if (num % 2 === 0){
            return greatestFactor(num)
        } else {
            return num
        }
    })
}
console.log(greatestFactorArray([16, 7, 9, 14])); // [8, 7, 9, 7]
console.log(greatestFactorArray([30, 3, 24, 21, 10])); // [15, 3, 12, 21, 5]


function summation(num){
    let sum = 0;
    for (let i = 1; i <= num; i++){
        sum += i
    }
    return sum
}


function summationSequence(start,length){
    let result = [start];

    for (let i = 1; i < length; i++){
        const nextElement = summation(result[i - 1])
        result.push(nextElement)
    }
    return result;
}

console.log(summationSequence(3, 4)); // [3, 6, 21, 231]
console.log(summationSequence(5, 3)); // [5, 15, 120]