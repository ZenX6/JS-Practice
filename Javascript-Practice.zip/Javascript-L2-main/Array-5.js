function popper(array, num){
    let removedArr = []

    for (let i = 0; i < num; i++){
        if (array.length > 0){
            removedArr.unshift(array.pop())
        }
    }
    return removedArr
}
let arr1 = ['a', 'b', 'c', 'd', 'e'];
console.log(popper(arr1, 2)); // [ 'e', 'd' ]
console.log(arr1); // [ 'a', 'b', 'c' ]

let arr2 = ['kale', 'spinach', 'collard greens', 'cabbage'];
console.log(popper(arr2, 1)); // [ 'cabbage' ]
console.log(arr2); // [ 'kale', 'spinach', 'collard greens' ]


//Second Question 

function rotateRight(array, num){
    let actualShifts = num % array.length;

    let lastPortion = array.slice(-actualShifts)

    let firstPortion = array.slice(0, array.length - actualShifts)

    return lastPortion.concat(firstPortion)
}

let arr = ['a', 'b', 'c', 'd', 'e'];
console.log(rotateRight(arr, 2)); // [ 'd', 'e', 'a', 'b', 'c' ]
console.log(arr); // [ 'a', 'b', 'c', 'd', 'e' ]

let animals = ['wombat', 'koala', 'opossum', 'kangaroo'];
console.log(rotateRight(animals, 3)); // [ 'koala', 'opossum', 'kangaroo', 'wombat' ]
console.log(animals); // [ 'wombat', 'koala', 'opossum', 'kangaroo' ]

