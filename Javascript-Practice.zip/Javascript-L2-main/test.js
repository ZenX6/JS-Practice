function isVowel(word){
    const vowels = 'AEIOUaeiou'
    
    for (let i = 0; i < vowels.length; i++){
        if (word === vowels[i]){
            return true
        }
    } 
    return false
}

function transformWord(word){
    if (word.length < 3){
        return word
    }

    for (let i = word.length; i >= 0; i--){
        if (isVowel(word[i])){
            return word + word.slice(i)
        }
    }
    return word
}

function repeatingTranslate(str){
    let words = str.split(' ')

    for (let i = 0; i < words.length; i++){
        words[i] = transformWord(words[i])
    }
    
    return words.join(' ')
}

console.log(repeatingTranslate("we like to go running fast"));  // "we likelike to go runninging fastast"
console.log(repeatingTranslate("he cannot find the trash"));    // "he cannotot findind thethe trashash"
console.log(repeatingTranslate("pasta is my favorite dish"));   // "pastapasta is my favoritefavorite dishish"
console.log(repeatingTranslate("her family flew to France"));   // "herer familyily flewew to FranceFrance"


function consonantCancel(sentence) {
    
    const vowels = 'aeiou';

    function firstVowelIdx(word){
        for (let i = 0; i < word.length; i++){
            if (vowels.includes(word[i])){
                return i
            }
        }  
        return -1
    }
    let words = sentence.split(' ')

    let transformWords = words.map(newWord => {
        let vowelIdx = firstVowelIdx(newWord)
        if(vowelIdx !== -1){
            return newWord.slice(vowelIdx)
        } else{
            return ''
        }
    })
    return transformWords.join(' ')
}
console.log(consonantCancel("down the rabbit hole")); // "own e abbit ole"
console.log(consonantCancel("writing code is challenging")); // "iting ode is allenging"


function sameCharCollapse(str){
    let canCollapse = true

    while (canCollapse){
        canCollapse = false
        for (let i = 0; i < str.length; i++){
            if (str[i] === str[i + 1]){
                str = str.slice(0 , i) + str.slice(i + 2)
                canCollapse = true
                break
            }
        }
    }
    return str

}


console.log(sameCharCollapse("zzzxaaxy"));  // "zy"
// because zzzxaaxy -> zxaaxy -> zxxy -> zy
console.log(sameCharCollapse("uqrssrqvtt")); // "uv"
// because uqrssrqvtt -> uqrrqvtt -> uqqvtt -> uvtt -> uv